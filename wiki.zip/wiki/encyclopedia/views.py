from django import forms
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from . import util

entries = ["CSS", "DEE", "Django", "Git", "HTML", "Python"]
# content = 'Markdown Content'
class NewEntryForm(forms.Form):
    title = forms.CharField(label="New Title")
    content = forms.CharField(label="New Content")

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def title(request):
    return render(request, "encyclopedia/index.html", {
        util.get_entry(title)
    })

def add(request):
    if request.method == "POST":
        form = NewEntryForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data["title"]
            content = form.cleaned_data["content"]
            entries.append(title)
            util.save_entry(title, content)
            return HttpResponseRedirect(reverse("index")) 
        else:
            return render(request, "encyclopedia/add.html", {
                "form": form
            })
    
    return render(request, "encyclopedia/add.html", {
        "form" : NewEntryForm()
    }) 
